to cstrike/sprites/hud.txt

d_laserfist				640 640hud44	172	128	48	16